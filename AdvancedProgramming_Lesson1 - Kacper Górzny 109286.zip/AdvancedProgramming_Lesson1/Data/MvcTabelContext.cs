﻿using AdvancedProgramming_Lesson1.Models;
using Microsoft.EntityFrameworkCore;

namespace AdvancedProgramming_Lesson1.Data
{
    public class MvcTabelContext : DbContext
    {
        public MvcTabelContext(DbContextOptions<MvcTabelContext> options)
        : base(options)
        {
        }
        public DbSet<Tabel> Tabel { get; set; }
    }
}
