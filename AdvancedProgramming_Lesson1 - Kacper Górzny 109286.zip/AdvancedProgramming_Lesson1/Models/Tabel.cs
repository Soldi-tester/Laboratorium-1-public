﻿using System;
using System.ComponentModel.DataAnnotations;

namespace AdvancedProgramming_Lesson1.Models
{
    public class Tabel
    {
        [Display(Name = "Identyfikator2")]
        public int Id { get; set; }
        [Required]
        [Display(Name = "Nazwa")]
        public string Title { get; set; }
        
        [DataType(DataType.Date)]
        [Display(Name = "Data produkcji")]
        public DateTime ReleaseDate { get; set; }
        [Required]
        [Display(Name = "Rodzaj")]
        public string Genre { get; set; }
        [Range(1, 1000)]
        [Display(Name = "Magazynek")]
        public decimal Price { get; set; }

    }
}
