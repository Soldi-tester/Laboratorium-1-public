﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using AdvancedProgramming_Lesson1.Data;
using AdvancedProgramming_Lesson1.Models;

namespace AdvancedProgramming_Lesson1.Controllers
{
    public class TabelController : Controller
    {
        private readonly MvcTabelContext _context;

        public TabelController(MvcTabelContext context)
        {
            _context = context;
        }

        // GET: Tabel
        public async Task<IActionResult> Index()
        {
            return View(await _context.Tabel.ToListAsync());
        }

        // GET: Tabel/Details/5
        public async Task<IActionResult> Details(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var tabel = await _context.Tabel
                .FirstOrDefaultAsync(m => m.Id == id);
            if (tabel == null)
            {
                return NotFound();
            }

            return View(tabel);
        }

        // GET: Tabel/Create
        public IActionResult Create()
        {
            return View();
        }

        // POST: Tabel/Create
        // To protect from overposting attacks, enable the specific properties you want to bind to, for 
        // more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("Id,Title,ReleaseDate,Genre,Price")] Tabel tabel)
        {
            if (ModelState.IsValid)
            {
                _context.Add(tabel);
                await _context.SaveChangesAsync();
                return RedirectToAction(nameof(Index));
            }
            return View(tabel);
        }

        // GET: Tabel/Edit/5
        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var tabel = await _context.Tabel.FindAsync(id);
            if (tabel == null)
            {
                return NotFound();
            }
            return View(tabel);
        }

        // POST: Tabel/Edit/5
        // To protect from overposting attacks, enable the specific properties you want to bind to, for 
        // more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, [Bind("Id,Title,ReleaseDate,Genre,Price")] Tabel tabel)
        {
            if (id != tabel.Id)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    _context.Update(tabel);
                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!TabelExists(tabel.Id))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                return RedirectToAction(nameof(Index));
            }
            return View(tabel);
        }

        // GET: Tabel/Delete/5
        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var tabel = await _context.Tabel
                .FirstOrDefaultAsync(m => m.Id == id);
            if (tabel == null)
            {
                return NotFound();
            }

            return View(tabel);
        }

        // POST: Tabel/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            var tabel = await _context.Tabel.FindAsync(id);
            _context.Tabel.Remove(tabel);
            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }

        private bool TabelExists(int id)
        {
            return _context.Tabel.Any(e => e.Id == id);
        }
    }
}
